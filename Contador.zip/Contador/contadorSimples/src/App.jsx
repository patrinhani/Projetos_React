import { useState } from "react";

import "./App.css";

function App() {
  const [value, setValue] = useState(0);

  return (
    <>
      <h1>
        {" "}
        Contador Simples com <span className="react">React</span>{" "}
      </h1>
      <h2 className='numero'>{value}</h2>
      <button
        className="botao botao-acrescentar"
        onClick={() => setValue(value + 1)}
      >
        Acrescentar
      </button>
      <button className="botao botao-reset" onClick={() => setValue(0)}>
        Reset
      </button>
      <button
        className="botao botao-diminuir"
        onClick={() => setValue(value - 1)}
      >
        Diminuir
      </button>
    </>
  );
}

export default App;
