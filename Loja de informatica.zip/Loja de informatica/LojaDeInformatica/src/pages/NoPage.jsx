function NoPage() {
  return <h1>Deu Ruim</h1>;
}

export default NoPage;
