import '../App.css'
import Header from '../components/Header'
import NavBar from '../components/NavBar'
import Centro from '../components/Centro'
import Section from '../components/Section'
import Footer from '../components/Footer'

function Home(){
    return(
        <>
        <Header />
        <NavBar />
        <Centro/>
        <Section/>
        <Footer/>
        </>
    )
}
export default Home