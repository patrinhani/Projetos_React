import { Outlet, Link } from "react-router-dom";

const Layout = () => {
  return (
    <>
      <nav>
        <ul>
          <li>
            <Link to="/">Home</Link>
          </li>
          <li>
            <Link to="./src/pages/Produtos">Produtos</Link>
          </li>
          <li>
            <Link to="/src/pages/Contatos">Contatos</Link>
          </li>
          <li>
            <Link to="/src/pages/Servicos">Serviços</Link>
          </li>
        </ul>
      </nav>

      <Outlet />
    </>
  )
};

export default Layout;