import "../App.css";
import Header from "../components/Header";
import NavBar from "../components/NavBar";
import Footer from "../components/Footer";
import Section from '../components/Section'
function Produtos() {
  return (
    <>
      <Header />
      <NavBar />

      
      <Section />
      <Footer />
    </>
  );
}

export default Produtos;
