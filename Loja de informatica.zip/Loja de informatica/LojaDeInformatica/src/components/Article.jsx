import "./article.css";

function Article() {
  return (
    <article className="sobre">
      <h2>Sobre Nós</h2>

      <img src="src/assets/img/img centro.png" alt=""/>
      <p>
        A loja de informática é o lugar ideal para aqueles que querem equipar
        seus computadores com os melhores produtos e serviços. Temos uma grande
        variedade de produtos de última geração para oferecer aos nossos
        clientes. Nossa equipe de profissionais altamente qualificados pode
        orientá-lo sobre os produtos certos para o seu computador, para garantir
        que você obtenha o melhor desempenho possível.
      </p>
      <p>
        Nossa loja oferece computadores, acessórios, software, hardware,
        equipamentos de rede e muito mais. Estamos sempre atualizando nossos
        produtos e serviços para garantir que os nossos clientes recebam a
        melhor qualidade e os melhores preços possíveis. Nossos técnicos
        altamente treinados podem ajudá-lo a instalar, configurar e solucionar
        problemas técnicos com seus computadores.
      </p>
      <p>
        Fornecemos serviços de manutenção e reparo para computadores, notebooks
        e outros equipamentos de informática. Estamos comprometidos em fornecer
        serviços de qualidade aos nossos clientes a preços competitivos.
        Oferecemos aos nossos clientes serviços de suporte técnico profissional,
        para que possam obter o melhor desempenho possível dos seus
        computadores.
      </p>
      <p>
        Nossa loja oferece aos nossos clientes muitas ofertas e descontos
        especiais. Nós temos uma variedade de produtos e serviços à disposição a
        preços acessíveis. Estamos comprometidos em oferecer o melhor serviço
        possível e, por isso, estamos sempre procurando por novas maneiras de
        ajudar nossos clientes a economizar.
      </p>
      <p>
        Também oferecemos serviços de financiamento para nossos clientes, para
        que possam obter os equipamentos informáticos que precisam, sem ter que
        economizar por muito tempo. Nossa loja de informática oferece suporte
        técnico ao cliente 24 horas por dia, 7 dias por semana, para garantir
        que nossos clientes recebam o melhor serviço possível.
      </p>
      <p>
        Estamos orgulhosos de oferecer aos nossos clientes serviços de qualidade
        e preços acessíveis. Estamos comprometidos em ajudá-los a obter o melhor
        desempenho possível dos seus computadores e oferecemos aos nossos
        clientes serviços de suporte técnico para que possam obter ajuda quando
        precisarem. Se você estiver procurando por uma loja de informática,
        venha nos visitar para ver o que podemos fazer por você.
      </p>
    </article>
  );
}

export default Article;
