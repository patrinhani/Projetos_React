import "./section.css";

function Section() {
  return (
    <section className="newsletter">
      <h3>Newsletter</h3>
      <p>Receba nossas promoções por e-mail</p>
      <input type="text" placeholder="Insira  seu nome" />
      <input type="text" placeholder="Insira  seu e-mail" />
      <button>Inscrever-se</button>
    </section>
  );
}
export default Section;
