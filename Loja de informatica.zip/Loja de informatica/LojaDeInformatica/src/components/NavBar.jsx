import '../components/navbar.css'
import React from "react";
import { Outlet, Link } from "react-router-dom";
import Social_Icons from "../components/Social_Icons";


function NavBar() {
  return (
    <nav className="menu">
      <ul>
        <li>
          <Link to="/">Home</Link>
        </li>
        <li>
          <Link to="/produtos">Produtos</Link>
        </li>
        <li>
          <Link to="/contatos">Contatos</Link>
        </li>
        <li>
          <Link to="/servicos">Serviços</Link>
        </li>
      </ul>
      <Social_Icons />
      <Outlet />
    </nav>
  );
}

export default NavBar;
