import "./social_icons.css";

function Social_icons() {
  return (
    <div className="social-icons ">
      <a
        href="https://www.facebook.com/profile.php?id=100090526503754"
        className="btn-facebook"
      >
        <i className="fa-brands fa-facebook"></i>
      </a>
      <a
        href="https://mail.google.com/mail/u/1/#inbox?compose=new"
        className="btn-google"
      >
        <i className="fa-brands fa-google"></i>
      </a>
      <a href="https://twitter.com/jajajaj32208508" className="btn-twitter">
        <i className="fa-brands fa-twitter"></i>
      </a>
    </div>
  );
}
export default Social_icons;
