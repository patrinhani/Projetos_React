import "./footer.css";

function Footer() {
  return (
    <div className="rodape">
      <p>&copy; Loja do Jaja - Todos os direitos reservados&copy;</p>
    </div>
  );
}
export default Footer;
