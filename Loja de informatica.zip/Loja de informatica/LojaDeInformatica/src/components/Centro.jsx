import Article from "./Article";
import Aside from "./Aside";
import './Centro.css'

function Centro(){

    return(
        <div className="principal ">
            <Article/>
            <Aside/>
        </div>
    )
}

export default Centro