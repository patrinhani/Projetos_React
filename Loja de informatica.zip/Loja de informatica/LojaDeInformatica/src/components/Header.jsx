import "./header.css";

function Header() {
  return (
    <div className="cabecalho">
    <h1 className="logo">
      <a href="index.html" title="loja do jaja ">Loja de Informática do Jaja</a>
    </h1>
    <form action="" method="post">
      <input type="search" name="busca" id="busca" placeholder="Faça sua busca aqui!" />
      <button><i class="fa-solid fa-magnifying-glass"></i></button>
    </form>
    </div>
  );
}



export default Header;
